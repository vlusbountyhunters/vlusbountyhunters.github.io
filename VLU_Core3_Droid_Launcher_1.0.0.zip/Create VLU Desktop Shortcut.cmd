@echo off
set "TARGET=%~dp0VLUCore3Launcher.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\VLU Core3 Launcher.lnk');$s.TargetPath='%TARGET%';$s.WorkingDirectory='%~dp0';$s.Save()"
if errorlevel 1 (
  echo Could not create the desktop shortcut.
) else (
  echo VLU Core3 Launcher shortcut created on your desktop.
)
pause
