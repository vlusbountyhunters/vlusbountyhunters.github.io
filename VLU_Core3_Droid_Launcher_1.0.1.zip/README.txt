SWG SOM launcher 2026.10.11.2
Close the game and launcher, then run SWG_SOM_launcher_20261011_r2.exe.
Select SOM pre-cu and your existing game folder; Scan / Update before Play.
